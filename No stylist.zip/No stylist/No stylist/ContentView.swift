//
//  ContentView.swift
//  No stylist
//
//  Created by Gleb Korotkov on 04.05.2024.
//

import SwiftUI
import UIKit

struct ContentView: View {
    @State private var selectedImage: UIImage?
    @State private var isShowingImagePicker = false
    @State private var isShowingFilter = false
    @State private var selectedFilter: Filter = .original

    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all) // Черный фон приложения

            VStack {
                if let SelectedPhoto = selectedImage {
                    HStack {
                        Button("Назад") {
                            selectedImage = nil
                            selectedFilter = .original
                        }
                        Spacer()
                        Button("Сохранить изображение") {
                            UIImageWriteToSavedPhotosAlbum(SelectedPhoto, nil, nil, nil)
                        }
                    }
                    .padding(.horizontal) // Горизонтальный отступ для кнопок
                    Image(uiImage: SelectedPhoto)
                        .resizable()
                        .aspectRatio(contentMode: .fit)

                    Spacer()
                    ScrollView(.horizontal){
                        
                    }
                    ScrollView(.horizontal) {
                        HStack(spacing: 20) {
                            ForEach(Filter.allCases, id: \.self) { filter in
                                FilterButton(filter: filter, selectedFilter: $selectedFilter)
                            }
                        }
                        .padding()
                        .background(Color.black)
                    }
                    Spacer()
                } else {
                    HStack(spacing:20){
                        Text("NO STYLIST").font(.custom("Avenir", size: 20))
                    }
                    Spacer()
                    Button("Выбрать изображение") {
                        isShowingImagePicker = true
                    }
                    Spacer()
                }
            }
            .foregroundColor(.white)
        }
        .sheet(isPresented: $isShowingImagePicker, onDismiss: loadImage) {
            ImagePicker(image: $selectedImage, isPresented: $isShowingImagePicker)
        }
    }

    func loadImage() {
    }
}

struct FilterButton: View {
    let filter: Filter
    @Binding var selectedFilter: Filter

    var body: some View {
        Button(action: {
            selectedFilter = filter
        }) {
            Text(filter.name)
                .padding()
                .background(selectedFilter == filter ? Color.blue : Color.gray)
                .cornerRadius(10)
                .foregroundColor(.white)
        }
    }
}

enum Filter: String, CaseIterable {
    case original = "Оригинал"
    case sepia = "Сепия"
    case blackAndWhite = "Черно-бел"

    var name: String {
        return rawValue
    }
}
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Binding var isPresented: Bool

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.originalImage] as? UIImage {
                parent.image = selectedImage
            }
            parent.isPresented = false // Скрыть ImagePicker после выбора изображения
        }
    }
}
#Preview {
    ContentView()
}
