//
//  No_stylistApp.swift
//  No stylist
//
//  Created by Gleb Korotkov on 04.05.2024.
//

import SwiftUI

@main
struct No_stylistApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
